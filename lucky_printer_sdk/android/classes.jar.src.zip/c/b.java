/* 1 */ package c;public final class b implements Runnable { public final void run() { this.a.onReadData(this.b); }
/*   */ 
/*   */   
/*   */   public b(ReadDataCallback paramReadDataCallback, byte[] paramArrayOfbyte) {} }


/* Location:              C:\Users\Omen\Downloads\app lucky printer\android-printing-sdk-demo-doc\android-printing-sdk-demo\app\libs\test\classes.jar!\c\b.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */