/* 1 */ package com.itpp;public class Code941 { static { System.loadLibrary("Code941"); }
/*   */ 
/*   */   
/*   */   public static native byte[] code(byte[] paramArrayOfbyte);
/*   */   
/*   */   public static native byte[] itppfunction(byte[] paramArrayOfbyte); }


/* Location:              C:\Users\Omen\Downloads\app lucky printer\android-printing-sdk-demo-doc\android-printing-sdk-demo\app\libs\test\classes.jar!\com\itpp\Code941.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */