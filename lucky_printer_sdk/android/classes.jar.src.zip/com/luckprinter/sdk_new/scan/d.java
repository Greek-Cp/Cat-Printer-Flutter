/* 1 */ package com.luckprinter.sdk_new.scan;public final class d implements Runnable { public final void run() { BluetoothAdapter.getDefaultAdapter().startDiscovery(); }
/*   */    }


/* Location:              C:\Users\Omen\Downloads\app lucky printer\android-printing-sdk-demo-doc\android-printing-sdk-demo\app\libs\test\classes.jar!\com\luckprinter\sdk_new\scan\d.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */