package com.luckprinter.sdk_new;

public class PrinterStatus {
  public static final int PRINTER_STATUS_OUTPAPER = 0;
  
  public static final int PRINTER_STATUS_OPENCOVER = 1;
  
  public static final int PRINTER_STATUS_OVERHEAT = 2;
  
  public static final int PRINTER_STATUS_LOWVAL = 3;
  
  public static final int PRINTER_STATUS_PRINTTING = 4;
  
  public static final int PRINTER_STATUS_RECHARGE = 5;
}


/* Location:              C:\Users\Omen\Downloads\app lucky printer\android-printing-sdk-demo-doc\android-printing-sdk-demo\app\libs\test\classes.jar!\com\luckprinter\sdk_new\PrinterStatus.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */