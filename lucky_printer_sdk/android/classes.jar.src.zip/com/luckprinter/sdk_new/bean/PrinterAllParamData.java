/* 1 */ package com.luckprinter.sdk_new.bean;public class PrinterAllParamData { private String bluetoothName; private String bluetoothMac; public String getBluetoothName() { return this.bluetoothName; } private String version; private String sn; private String battery; public void setBluetoothName(String paramString) { this.bluetoothName = paramString; } public String getBluetoothMac() { return this.bluetoothMac; } public void setBluetoothMac(String paramString) { this.bluetoothMac = paramString; } public String getVersion() { return this.version; } public void setVersion(String paramString) { this.version = paramString; } public String getSn() { return this.sn; } public void setSn(String paramString) { this.sn = paramString; } public String getBattery() { return this.battery; } public void setBattery(String paramString) { this.battery = paramString; }
/*   */    }


/* Location:              C:\Users\Omen\Downloads\app lucky printer\android-printing-sdk-demo-doc\android-printing-sdk-demo\app\libs\test\classes.jar!\com\luckprinter\sdk_new\bean\PrinterAllParamData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */