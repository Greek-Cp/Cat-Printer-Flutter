/* 1 */ package com.luckprinter.sdk_new.bean;public class PrinterStatusData { private int isPrinting; private int isOpen; private int isLackPaper; public int getIsPrinting() { return this.isPrinting; } private int isLackElec; private int isOverheat; private int isRecharge; public void setIsPrinting(int paramInt) { this.isPrinting = paramInt; } public int getIsOpen() { return this.isOpen; } public void setIsOpen(int paramInt) { this.isOpen = paramInt; } public int getIsLackPaper() { return this.isLackPaper; } public void setIsLackPaper(int paramInt) { this.isLackPaper = paramInt; } public int getIsLackElec() { return this.isLackElec; } public void setIsLackElec(int paramInt) { this.isLackElec = paramInt; } public int getIsOverheat() { return this.isOverheat; } public void setIsOverheat(int paramInt) { this.isOverheat = paramInt; } public int getIsRecharge() { return this.isRecharge; } public void setIsRecharge(int paramInt) { this.isRecharge = paramInt; }
/*   */    }


/* Location:              C:\Users\Omen\Downloads\app lucky printer\android-printing-sdk-demo-doc\android-printing-sdk-demo\app\libs\test\classes.jar!\com\luckprinter\sdk_new\bean\PrinterStatusData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */