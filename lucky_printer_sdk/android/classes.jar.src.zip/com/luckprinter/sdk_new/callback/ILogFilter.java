package com.luckprinter.sdk_new.callback;

public interface ILogFilter {
  void onLog(String paramString);
}


/* Location:              C:\Users\Omen\Downloads\app lucky printer\android-printing-sdk-demo-doc\android-printing-sdk-demo\app\libs\test\classes.jar!\com\luckprinter\sdk_new\callback\ILogFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */