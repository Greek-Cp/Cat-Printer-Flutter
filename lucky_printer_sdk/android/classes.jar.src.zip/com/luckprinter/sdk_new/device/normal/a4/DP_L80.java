package com.luckprinter.sdk_new.device.normal.a4;

import com.luckprinter.sdk_new.device.normal.base.BaseA4Device;

public class DP_L80 extends BaseA4Device {}


/* Location:              C:\Users\Omen\Downloads\app lucky printer\android-printing-sdk-demo-doc\android-printing-sdk-demo\app\libs\test\classes.jar!\com\luckprinter\sdk_new\device\normal\a4\DP_L80.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */