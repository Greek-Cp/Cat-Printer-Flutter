package com.luckprinter.sdk_new.device.normal;

import com.luckprinter.sdk_new.device.normal.base.BaseNormalDevice;

public class LuckP_L1F extends BaseNormalDevice {}


/* Location:              C:\Users\Omen\Downloads\app lucky printer\android-printing-sdk-demo-doc\android-printing-sdk-demo\app\libs\test\classes.jar!\com\luckprinter\sdk_new\device\normal\LuckP_L1F.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */