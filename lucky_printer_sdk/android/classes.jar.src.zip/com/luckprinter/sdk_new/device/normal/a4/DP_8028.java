package com.luckprinter.sdk_new.device.normal.a4;

public class DP_8028 extends DP_A4 {}


/* Location:              C:\Users\Omen\Downloads\app lucky printer\android-printing-sdk-demo-doc\android-printing-sdk-demo\app\libs\test\classes.jar!\com\luckprinter\sdk_new\device\normal\a4\DP_8028.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */