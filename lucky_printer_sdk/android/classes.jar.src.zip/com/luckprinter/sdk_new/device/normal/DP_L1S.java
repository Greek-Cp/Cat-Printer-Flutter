/*   */ package com.luckprinter.sdk_new.device.normal;public class DP_L1S extends BaseNormalDevice { public DP_L1S() {
/* 2 */     setCompress(true);
/*   */   } }


/* Location:              C:\Users\Omen\Downloads\app lucky printer\android-printing-sdk-demo-doc\android-printing-sdk-demo\app\libs\test\classes.jar!\com\luckprinter\sdk_new\device\normal\DP_L1S.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */