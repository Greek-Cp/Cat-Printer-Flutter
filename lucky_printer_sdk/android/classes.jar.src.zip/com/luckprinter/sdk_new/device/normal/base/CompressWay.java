package com.luckprinter.sdk_new.device.normal.base;

public interface CompressWay {
  public static final int COMPRESS_WAY_DEFAULT = 0;
  
  public static final int COMPRESS_WAY_LIHU = 1;
}


/* Location:              C:\Users\Omen\Downloads\app lucky printer\android-printing-sdk-demo-doc\android-printing-sdk-demo\app\libs\test\classes.jar!\com\luckprinter\sdk_new\device\normal\base\CompressWay.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */