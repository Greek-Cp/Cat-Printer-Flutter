/*   */ package com.luckprinter.sdk_new.device.normal;public class DP_D2H extends C21E { public DP_D2H() {
/* 2 */     is300Dpi();
/*   */   }
/*   */   
/*   */   public boolean is300Dpi() {
/*   */     return true;
/*   */   } }


/* Location:              C:\Users\Omen\Downloads\app lucky printer\android-printing-sdk-demo-doc\android-printing-sdk-demo\app\libs\test\classes.jar!\com\luckprinter\sdk_new\device\normal\DP_D2H.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */