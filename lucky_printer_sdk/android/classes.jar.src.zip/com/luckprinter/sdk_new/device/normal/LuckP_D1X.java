/* 1 */ package com.luckprinter.sdk_new.device.normal;public class LuckP_D1X extends BaseNormalDevice { public void printerModelLuck(ResultCallback<String> paramResultCallback) { PrinterUtil.runOnUi(() -> paramResultCallback.onSuccess("D1X-KD")); }
/*   */ 
/*   */   
/*   */   public static final String PRINTER_MODEL = "D1X-KD"; }


/* Location:              C:\Users\Omen\Downloads\app lucky printer\android-printing-sdk-demo-doc\android-printing-sdk-demo\app\libs\test\classes.jar!\com\luckprinter\sdk_new\device\normal\LuckP_D1X.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */