/*   */ package com.luckprinter.sdk_new.device.normal.a4;public class DP_A80H extends BaseA4Device { public DP_A80H() {
/* 2 */     setCompress(true);
/* 3 */     setCompressWay(1);
/*   */   }
/*   */   
/*   */   public boolean is300Dpi() {
/*   */     return true;
/*   */   } }


/* Location:              C:\Users\Omen\Downloads\app lucky printer\android-printing-sdk-demo-doc\android-printing-sdk-demo\app\libs\test\classes.jar!\com\luckprinter\sdk_new\device\normal\a4\DP_A80H.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */