package com.luckprinter.sdk_new.device.normal;

public class CRAFTS_CO_4777 extends LuckP_D1 {}


/* Location:              C:\Users\Omen\Downloads\app lucky printer\android-printing-sdk-demo-doc\android-printing-sdk-demo\app\libs\test\classes.jar!\com\luckprinter\sdk_new\device\normal\CRAFTS_CO_4777.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */