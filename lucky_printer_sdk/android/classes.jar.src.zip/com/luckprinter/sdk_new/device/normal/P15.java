/*   */ package com.luckprinter.sdk_new.device.normal;public class P15 extends BaseNormalDevice { public P15() {
/* 2 */     setEnablePrinterMode(2);
/*   */   }
/*   */   
/*   */   public int getPrintWidth() {
/*   */     return 96;
/*   */   } }


/* Location:              C:\Users\Omen\Downloads\app lucky printer\android-printing-sdk-demo-doc\android-printing-sdk-demo\app\libs\test\classes.jar!\com\luckprinter\sdk_new\device\normal\P15.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */