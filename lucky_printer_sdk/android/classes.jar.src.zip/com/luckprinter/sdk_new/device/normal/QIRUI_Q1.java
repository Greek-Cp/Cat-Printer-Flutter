/*   */ package com.luckprinter.sdk_new.device.normal;public class QIRUI_Q1 extends BaseNormalDevice { public QIRUI_Q1() {
/* 2 */     setEnablePrinterMode(2);
/* 3 */     setCompress(false);
/*   */   }
/*   */   
/*   */   public boolean is300Dpi() {
/*   */     return false;
/*   */   } }


/* Location:              C:\Users\Omen\Downloads\app lucky printer\android-printing-sdk-demo-doc\android-printing-sdk-demo\app\libs\test\classes.jar!\com\luckprinter\sdk_new\device\normal\QIRUI_Q1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */