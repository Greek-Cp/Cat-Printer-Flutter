/*   */ package com.luckprinter.sdk_new.device.normal;public class DP_S1H extends DP_S1 { public DP_S1H() {
/* 2 */     setEndLineDot(144);
/*   */   } }


/* Location:              C:\Users\Omen\Downloads\app lucky printer\android-printing-sdk-demo-doc\android-printing-sdk-demo\app\libs\test\classes.jar!\com\luckprinter\sdk_new\device\normal\DP_S1H.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */