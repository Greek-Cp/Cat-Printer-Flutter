/*   */ package com.luckprinter.sdk_new.device.normal.a4;public class DP_A46 extends BaseLuckPA4Device { public DP_A46() {
/* 2 */     setMinDensity(0);
/* 3 */     setMaxDensity(15);
/* 4 */     setMinSpeed(0);
/* 5 */     setMaxSpeed(8);
/* 6 */     setSupportSetSpeed(false);
/*   */   } }


/* Location:              C:\Users\Omen\Downloads\app lucky printer\android-printing-sdk-demo-doc\android-printing-sdk-demo\app\libs\test\classes.jar!\com\luckprinter\sdk_new\device\normal\a4\DP_A46.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */