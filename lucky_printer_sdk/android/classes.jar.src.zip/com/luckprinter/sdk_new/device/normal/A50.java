/*   */ package com.luckprinter.sdk_new.device.normal;public class A50 extends BaseNormalDevice { public A50() {
/* 2 */     setMinDensity(0);
/* 3 */     setMaxDensity(16);
/* 4 */     setCompress(true);
/* 5 */     setTagNeedAdjustPaper(true);
/* 6 */     setEndLineDot(140);
/*   */   } }


/* Location:              C:\Users\Omen\Downloads\app lucky printer\android-printing-sdk-demo-doc\android-printing-sdk-demo\app\libs\test\classes.jar!\com\luckprinter\sdk_new\device\normal\A50.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */