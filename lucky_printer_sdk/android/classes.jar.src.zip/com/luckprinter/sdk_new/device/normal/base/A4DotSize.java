package com.luckprinter.sdk_new.device.normal.base;

public class A4DotSize {
  public static final int WIDTH_210_200DPI = 1616;
  
  public static final int WIDTH_216_200DPI = 1648;
  
  public static final int WIDTH_210_300DPI = 2400;
  
  public static final int WIDTH_216_300DPI = 2496;
  
  public static final int HEIGHT_148_200DPI = 1108;
  
  public static final int HEIGHT_279_200DPI = 2160;
  
  public static final int HEIGHT_297_200DPI = 2300;
  
  public static final int HEIGHT_355_200DPI = 2768;
  
  public static final int HEIGHT_148_300DPI = 1692;
  
  public static final int HEIGHT_279_300DPI = 3240;
  
  public static final int HEIGHT_297_300DPI = 3480;
  
  public static final int HEIGHT_355_300DPI = 4152;
}


/* Location:              C:\Users\Omen\Downloads\app lucky printer\android-printing-sdk-demo-doc\android-printing-sdk-demo\app\libs\test\classes.jar!\com\luckprinter\sdk_new\device\normal\base\A4DotSize.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */