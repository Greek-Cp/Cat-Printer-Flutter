package com.luckprinter.sdk_new.device.normal;

import com.luckprinter.sdk_new.device.normal.base.BaseNormalDevice;

public class A12 extends BaseNormalDevice {
  public int getPrintWidth() {
    return 96;
  }
}


/* Location:              C:\Users\Omen\Downloads\app lucky printer\android-printing-sdk-demo-doc\android-printing-sdk-demo\app\libs\test\classes.jar!\com\luckprinter\sdk_new\device\normal\A12.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */