package com.luckprinter.sdk_new.device.normal.a4;

import com.luckprinter.sdk_new.device.normal.base.BaseLuckPA4Device;

public class DP_A47 extends BaseLuckPA4Device {}


/* Location:              C:\Users\Omen\Downloads\app lucky printer\android-printing-sdk-demo-doc\android-printing-sdk-demo\app\libs\test\classes.jar!\com\luckprinter\sdk_new\device\normal\a4\DP_A47.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */