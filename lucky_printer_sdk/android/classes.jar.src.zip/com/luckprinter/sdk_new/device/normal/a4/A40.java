/*   */ package com.luckprinter.sdk_new.device.normal.a4;public class A40 extends BaseA4Device { public A40() {
/* 2 */     setCompress(false);
/*   */   } }


/* Location:              C:\Users\Omen\Downloads\app lucky printer\android-printing-sdk-demo-doc\android-printing-sdk-demo\app\libs\test\classes.jar!\com\luckprinter\sdk_new\device\normal\a4\A40.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */