/*   */ package com.luckprinter.sdk_new.device.normal;public class QIRUI_Q2 extends BaseNormalDevice { public QIRUI_Q2() {
/* 2 */     setEnablePrinterMode(2);
/* 3 */     setEndLineDot(130);
/* 4 */     setCompress(false);
/*   */   }
/*   */   
/*   */   public boolean is300Dpi() {
/*   */     return true;
/*   */   } }


/* Location:              C:\Users\Omen\Downloads\app lucky printer\android-printing-sdk-demo-doc\android-printing-sdk-demo\app\libs\test\classes.jar!\com\luckprinter\sdk_new\device\normal\QIRUI_Q2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */