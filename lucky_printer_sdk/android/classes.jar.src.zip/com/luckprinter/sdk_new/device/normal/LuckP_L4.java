/*   */ package com.luckprinter.sdk_new.device.normal;public class LuckP_L4 extends BaseNormalDevice { public LuckP_L4() {
/* 2 */     setCompress(true);
/*   */   }
/*   */   
/*   */   public int getPrintWidth() {
/*   */     return 824;
/*   */   } }


/* Location:              C:\Users\Omen\Downloads\app lucky printer\android-printing-sdk-demo-doc\android-printing-sdk-demo\app\libs\test\classes.jar!\com\luckprinter\sdk_new\device\normal\LuckP_L4.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */