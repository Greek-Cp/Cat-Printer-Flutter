/* 1 */ package com.luckprinter.sdk_new.device.normal;public class LuckP_L1X extends BaseNormalDevice { public void printerModelLuck(ResultCallback<String> paramResultCallback) { PrinterUtil.runOnUi(() -> paramResultCallback.onSuccess("L1X-RD")); }
/*   */ 
/*   */   
/*   */   private static final String PRINTER_MODEL = "L1X-RD"; }


/* Location:              C:\Users\Omen\Downloads\app lucky printer\android-printing-sdk-demo-doc\android-printing-sdk-demo\app\libs\test\classes.jar!\com\luckprinter\sdk_new\device\normal\LuckP_L1X.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */