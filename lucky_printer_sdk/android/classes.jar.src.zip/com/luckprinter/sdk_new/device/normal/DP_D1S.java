package com.luckprinter.sdk_new.device.normal;

public class DP_D1S extends DP_D1 {}


/* Location:              C:\Users\Omen\Downloads\app lucky printer\android-printing-sdk-demo-doc\android-printing-sdk-demo\app\libs\test\classes.jar!\com\luckprinter\sdk_new\device\normal\DP_D1S.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */