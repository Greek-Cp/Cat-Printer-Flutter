/* 1 */ package com.luckprinter.sdk_new.device.custom;public class PaperSize { private int mm; public int getMm() { return this.mm; } private int realMm; public PaperSize() {} public void setMm(int paramInt) { this.mm = paramInt; } public int getRealMm() { return this.realMm; } public void setRealMm(int paramInt) { this.realMm = paramInt; } public PaperSize(int paramInt1, int paramInt2) {
/* 2 */     this
/* 3 */       .mm = paramInt1;
/* 4 */     this.realMm = paramInt2;
/*   */   } }


/* Location:              C:\Users\Omen\Downloads\app lucky printer\android-printing-sdk-demo-doc\android-printing-sdk-demo\app\libs\test\classes.jar!\com\luckprinter\sdk_new\device\custom\PaperSize.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */