/* 1 */ package com.luckprinter.sdk_new.device.custom;public class PrinterBootCommand { public List<Command> getCommands() { return this.commands; } private List<Command> commands; public void setCommands(List<Command> paramList) { this.commands = paramList; }
/*   */    }


/* Location:              C:\Users\Omen\Downloads\app lucky printer\android-printing-sdk-demo-doc\android-printing-sdk-demo\app\libs\test\classes.jar!\com\luckprinter\sdk_new\device\custom\PrinterBootCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */