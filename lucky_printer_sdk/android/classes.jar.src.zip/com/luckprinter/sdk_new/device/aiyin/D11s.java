package com.luckprinter.sdk_new.device.aiyin;

public class D11s extends AiYinNormalDevice {
  public int getPrintWidth() {
    return 96;
  }
}


/* Location:              C:\Users\Omen\Downloads\app lucky printer\android-printing-sdk-demo-doc\android-printing-sdk-demo\app\libs\test\classes.jar!\com\luckprinter\sdk_new\device\aiyin\D11s.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */