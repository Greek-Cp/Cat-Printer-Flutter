/* 1 */ package com.luckprinter.sdk_new.device;public enum ConnectWayEnum { CLASSIC,
/*   */   
/* 3 */   BLE; }


/* Location:              C:\Users\Omen\Downloads\app lucky printer\android-printing-sdk-demo-doc\android-printing-sdk-demo\app\libs\test\classes.jar!\com\luckprinter\sdk_new\device\ConnectWayEnum.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */