package com.luckprinter.sdk_new.device;

public interface PrinterType {
  public static final String normal = "normal";
  
  public static final String sheet_label = "sheet_label";
  
  public static final String a4 = "a4";
}


/* Location:              C:\Users\Omen\Downloads\app lucky printer\android-printing-sdk-demo-doc\android-printing-sdk-demo\app\libs\test\classes.jar!\com\luckprinter\sdk_new\device\PrinterType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */