package com.luckprinter.sdk_new.device;

public interface ISupportSelectPaper {
  void setSelectPaperSize(int paramInt);
  
  int getSelectPaperSize();
}


/* Location:              C:\Users\Omen\Downloads\app lucky printer\android-printing-sdk-demo-doc\android-printing-sdk-demo\app\libs\test\classes.jar!\com\luckprinter\sdk_new\device\ISupportSelectPaper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */