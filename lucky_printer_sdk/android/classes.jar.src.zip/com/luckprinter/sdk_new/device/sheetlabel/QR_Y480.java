/* 1 */ package com.luckprinter.sdk_new.device.sheetlabel;public class QR_Y480 extends BaseSheetLabelDevice { public void drawPic(Bitmap paramBitmap) { drawPicAngyin(paramBitmap); }
/*   */ 
/*   */   
/*   */   public int getPrintWidth() {
/*   */     return 800;
/*   */   } }


/* Location:              C:\Users\Omen\Downloads\app lucky printer\android-printing-sdk-demo-doc\android-printing-sdk-demo\app\libs\test\classes.jar!\com\luckprinter\sdk_new\device\sheetlabel\QR_Y480.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */