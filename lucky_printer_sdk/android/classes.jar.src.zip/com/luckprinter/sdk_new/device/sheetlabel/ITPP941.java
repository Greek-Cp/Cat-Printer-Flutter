package com.luckprinter.sdk_new.device.sheetlabel;

import com.luckprinter.sdk_new.device.sheetlabel.base.BaseSheetLabelDevice;

public class ITPP941 extends BaseSheetLabelDevice {
  public int getPrintWidth() {
    return 864;
  }
}


/* Location:              C:\Users\Omen\Downloads\app lucky printer\android-printing-sdk-demo-doc\android-printing-sdk-demo\app\libs\test\classes.jar!\com\luckprinter\sdk_new\device\sheetlabel\ITPP941.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */