/*   */ package com.luckprinter.sdk_new.device.sheetlabel;public class P80S extends BaseSheetLabelDevice { public P80S() {
/* 2 */     setSupportSetSpeed(false);
/*   */   }
/*   */   
/*   */   public int getPrintWidth() {
/*   */     return 576;
/*   */   }
/*   */   
/*   */   public void drawPic(Bitmap paramBitmap) {
/*   */     drawPicAngyin(paramBitmap);
/*   */   } }


/* Location:              C:\Users\Omen\Downloads\app lucky printer\android-printing-sdk-demo-doc\android-printing-sdk-demo\app\libs\test\classes.jar!\com\luckprinter\sdk_new\device\sheetlabel\P80S.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */