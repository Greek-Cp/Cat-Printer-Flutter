/* 1 */ package d;public final class d implements ResultCallback { public final void onSuccess(Object paramObject) { (Integer)paramObject;
/* 2 */     this.a.d.setData(Boolean.TRUE);
/* 3 */     this.a.c.countDown(); }
/*   */ 
/*   */   
/*   */   public d(e parame) {}
/*   */   
/*   */   public final void onFail() {} }


/* Location:              C:\Users\Omen\Downloads\app lucky printer\android-printing-sdk-demo-doc\android-printing-sdk-demo\app\libs\test\classes.jar!\d\d.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */