/* 1 */ package a;public final class b { public b(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) { this
/* 2 */       .a = paramInt1;
/* 3 */     this.b = paramInt2;
/* 4 */     this.c = paramInt3;
/* 5 */     this.d = paramInt4;
/* 6 */     this.e = paramInt5; }
/*   */ 
/*   */   
/*   */   public final int a;
/*   */   public final int b;
/*   */   public final int c;
/*   */   public final int d;
/*   */   public final int e; }


/* Location:              C:\Users\Omen\Downloads\app lucky printer\android-printing-sdk-demo-doc\android-printing-sdk-demo\app\libs\test\classes.jar!\a\b.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */