package b;

public abstract class a {
  public static boolean a = false;
  
  public static String b;
  
  public static boolean c = false;
}


/* Location:              C:\Users\Omen\Downloads\app lucky printer\android-printing-sdk-demo-doc\android-printing-sdk-demo\app\libs\test\classes.jar!\b\a.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */