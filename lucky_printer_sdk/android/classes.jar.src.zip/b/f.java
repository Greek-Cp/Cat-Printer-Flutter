/* 1 */ package b;public final class f { public Timer a = null; public DeviceForbiddenListener b; public String c; public String d; public String e; public final void a() { PrinterHelper.getInstance().disconnectLuck();
/* 2 */     h.a("device already forbidden!!!");
/* 3 */     PrinterUtil.runOnUi(this::b); }
/*   */    }


/* Location:              C:\Users\Omen\Downloads\app lucky printer\android-printing-sdk-demo-doc\android-printing-sdk-demo\app\libs\test\classes.jar!\b\f.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */